package com.patient.dao;

import java.util.List;

import com.patient.pojos.BloodGlucose;

public interface BloodGlucoseDAO {
		public boolean addBloodGlucose(BloodGlucose bloodglucose);
		public boolean updateBloodGlucose(BloodGlucose bloodglucose);
		public boolean deleteBloodGlucose(String userid);
		public List<BloodGlucose> getAllBloodGlucose();
		public BloodGlucose getUserById(String userid);
		

	}




