package com.patient.dao;

import java.util.List;

import com.patient.pojos.Users;


public interface UsersDAO {
	public boolean addUser(Users user);
	public boolean updateUser(Users user);
	public boolean deleteUser(String userid);
	public List<Users> getAllUsers();
	public Users getUserById(String userid);
	public Users login(String userid,String password);

}
