package com.patient.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.patient.pojos.BloodGlucose;
import com.patient.pojos.Bmi;
import com.patient.utility.DBConnection;

public class BloodGlucoseDAOImpl implements BloodGlucoseDAO {

	@Override
	public boolean addBloodGlucose(BloodGlucose bloodglucose) {
		// TODO Auto-generated method stub
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query = "insert into bloodglucose (userid,time,bloodglucose) values(?,?,?)";
	        prSt =con.prepareStatement(query);
	       
	        prSt.setString(1,bloodglucose.getUserid());
	        prSt.setString(2,bloodglucose.getTime());
	        prSt.setInt(3,bloodglucose.getBloodglucose());
	       
	        int count = prSt.executeUpdate();
	        if(count>0)
	        	return true;
	       
			}
			catch(Exception e){
				e.printStackTrace();
			}
	        
		return false;
		
	}

	@Override
	public boolean updateBloodGlucose(BloodGlucose bloodglucose) {
		// TODO Auto-generated method stub
		try{
			// TODO Auto-generated method stub
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query = "update bloodglucose set time=?,bloodglucose=? where userid=?";
	       prSt =con.prepareStatement(query);
	      
	       prSt.setString(1,bloodglucose.getTime());
	       prSt.setInt(2,bloodglucose.getBloodglucose());
	       prSt.setString(3,bloodglucose.getUserid());
	       
	       int count = prSt.executeUpdate();
	       if(count>0)
	    	   return true;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return false;
	}

	@Override
	public boolean deleteBloodGlucose(String userid) {
		// TODO Auto-generated method stub
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			 String query = "delete from bloodglucose where userid=?";
	            prSt = con.prepareStatement(query);
	            prSt.setString(1,userid);
	            int count = prSt.executeUpdate();
	            if(count>0)
	         	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<BloodGlucose> getAllBloodGlucose() {
		// TODO Auto-generated method stub
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select*from bloodglucose";
            prSt = con.prepareStatement(query);
            ResultSet rs=prSt.executeQuery();
            List<BloodGlucose>bloodglucoseList=new ArrayList<BloodGlucose>();
            while(rs.next())
            {
            	BloodGlucose bloodglucose=new BloodGlucose();
            	bloodglucose.setTime(rs.getString("time"));
            	bloodglucose.setBloodglucose(rs.getInt("bloodglucose"));
            	bloodglucose.setUserid(rs.getString("userid"));
            	
            	bloodglucoseList.add(bloodglucose);
            }
            return bloodglucoseList;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public BloodGlucose getUserById(String userid) {
		// TODO Auto-generated method stub
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select* from bloodglucose where userid=?";
	        prSt = con.prepareStatement(query);
	        prSt.setString(1,userid);
	        ResultSet rs=prSt.executeQuery();
	       
	        if(rs.next())
	        {
	        	BloodGlucose bloodglucose=new BloodGlucose();
            	bloodglucose.setBloodglucose(rs.getInt("bloodglucose"));
            	bloodglucose.setTime(rs.getString("time"));
            	bloodglucose.setUserid(rs.getString("userid"));
            	
	        	return bloodglucose;
	        }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

}

