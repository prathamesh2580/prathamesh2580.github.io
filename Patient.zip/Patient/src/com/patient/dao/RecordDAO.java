package com.patient.dao;

import java.util.List;

import com.patient.pojos.Record;

public interface RecordDAO {
	public boolean addRecord(Record record);
	public boolean updateRecord(Record record);
	public boolean deleteRecord(String userid);
	public List<Record> getAllRecord();
	public Record getRecordByUserid(String userid);

}
