package com.patient.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.patient.pojos.Bmi;
import com.patient.pojos.Users;
import com.patient.utility.DBConnection;

public class BmiDAOImpl implements BmiDAO {

	@Override
	public boolean addBmi(Bmi bmi) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query = "insert into bmi (userid,height,weight,bmi_value) values(?,?,?,?)";
	        prSt =con.prepareStatement(query);
            	       
	        prSt.setString(1,bmi.getUserid());
	        prSt.setInt(2,bmi.getHeight());
	        prSt.setInt(3,bmi.getWeight());
	        prSt.setFloat(4,bmi.getBmi_value());
	        
	        int count = prSt.executeUpdate();
	        if(count>0)
	        	return true;
	       
			}
			catch(Exception e){
				e.printStackTrace();
			}
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUser(Bmi bmi) {
		try{
		Connection con=DBConnection.getConnection();
		 PreparedStatement prSt = null;
		String query = "update bmi set height=?,weight=?,bmi-value=? where userid=?";
      prSt =con.prepareStatement(query);
     
      prSt.setInt(1,bmi.getHeight());
      prSt.setInt(2,bmi.getWeight());
      prSt.setFloat(3,bmi.getBmi_value());
      prSt.setString(4,bmi.getUserid());
      
      int count = prSt.executeUpdate();
      if(count>0)
   	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteBmi(String userid) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			 String query = "delete from bmi where userid=?";
	            prSt = con.prepareStatement(query);
	            prSt.setString(1,userid);
	            int count = prSt.executeUpdate();
	            if(count>0)
	         	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Bmi> getAllData() {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select*from bmi";
            prSt = con.prepareStatement(query);
            ResultSet rs=prSt.executeQuery();
            List<Bmi>dataList=new ArrayList<Bmi>();
            while(rs.next())
            {
            	Bmi bmi=new Bmi();
            	bmi.setUserid(rs.getString("userid"));
            	bmi.setHeight(rs.getInt("height"));
            	bmi.setWeight(rs.getInt("weight"));
            	bmi.setBmi_value(rs.getFloat("bmi_value"));
            	dataList.add(bmi);
            }
            return dataList;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bmi getDataById(String userid) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select* from bmi where userid=?";
	        prSt = con.prepareStatement(query);
	        prSt.setString(1,userid);
	        ResultSet rs=prSt.executeQuery();
	       
	        if(rs.next())
	        {
	        	Bmi bmi=new Bmi();
	        	bmi.setUserid(rs.getString("userid"));
            	bmi.setHeight(rs.getInt("height"));
            	bmi.setWeight(rs.getInt("weight"));
            	bmi.setBmi_value(rs.getFloat("bmi_value"));
	        	return bmi;
	        }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}

}
