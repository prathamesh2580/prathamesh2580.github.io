 package com.patient.dao;

import java.util.List;

import com.patient.pojos.Bmi;



public interface BmiDAO {
	public boolean addBmi(Bmi bmi);
	public boolean updateUser(Bmi bmi);
	public boolean deleteBmi(String userid);
	public List<Bmi> getAllData();
	public Bmi getDataById(String userid);
	
}
