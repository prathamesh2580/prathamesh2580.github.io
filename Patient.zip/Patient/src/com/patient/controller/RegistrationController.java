package com.patient.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.UsersDAO;
import com.patient.dao.UsersDAOImpl;
import com.patient.pojos.Users;



/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String first_name=request.getParameter("first_name");
		String last_name=request.getParameter("last_name");
		String age=request.getParameter("age");
		String gender=request.getParameter("gender");
		String contact_number=request.getParameter("contact_number");
		String email=request.getParameter("email");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		String type=request.getParameter("type");
		Users user=new Users();
		user.setFirst_name(first_name);
		user.setLast_name(last_name);
		user.setAge(Integer.parseInt(age));
		user.setGender(gender);
		user.setContact_number(contact_number);
		user.setEmail(email);
		user.setCity(city);
		user.setState(state);
		user.setUserid(userid);
		user.setPassword(password);
		user.setType(type);
		UsersDAO dao=new UsersDAOImpl();
		boolean flag=dao.addUser(user);
		HttpSession session=request.getSession();
		if(flag==true)
		{
			session .setAttribute("message","New user created successfully");
			response.sendRedirect("Login.jsp");
		}
			
		else
		{
			session .setAttribute("message","Failed to create new user");
			response.sendRedirect("Registration.jsp");
		}
			
	}

}
