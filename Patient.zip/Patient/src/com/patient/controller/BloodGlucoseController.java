package com.patient.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.BloodGlucoseDAO;
import com.patient.dao.BloodGlucoseDAOImpl;
import com.patient.dao.BmiDAO;
import com.patient.dao.BmiDAOImpl;
import com.patient.dao.UsersDAO;
import com.patient.dao.UsersDAOImpl;
import com.patient.pojos.BloodGlucose;
import com.patient.pojos.Bmi;
import com.patient.pojos.Users;
import com.patient.utility.Diabetes;

/**
 * Servlet implementation class BloodGlucoseController
 */
@WebServlet("/BloodGlucoseController")
public class BloodGlucoseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BloodGlucoseController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BloodGlucoseDAO dao=new BloodGlucoseDAOImpl();
		HttpSession session=request.getSession();
		List<BloodGlucose> bloodglucoselist=dao.getAllBloodGlucose();
		session.setAttribute("bloodglucoselist",bloodglucoselist);
		response.sendRedirect("BloodGlucoseList.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		Users user=(Users)session.getAttribute("users");
		
		String time=request.getParameter("time");
		String bloodglucose=request.getParameter("bloodglucose");
		BloodGlucose glucose=new BloodGlucose();
		int bg=Integer.parseInt(bloodglucose);
		glucose.setUserid(user.getUserid());
        glucose.setTime(time);
        glucose.setBloodglucose(Integer.parseInt(bloodglucose));
        BloodGlucoseDAO dao=new BloodGlucoseDAOImpl();
        Diabetes dia=new Diabetes();
        boolean risk=dia.risk(time,bg);
		 boolean flag=dao.addBloodGlucose(glucose);
		 
          if(risk==true&&flag==true)
          {
              session.setAttribute("message","Record Entered Successfully<br>Risk");
               response.sendRedirect("BloodGlucoseList.jsp");
        }
          else if(risk==false&&flag==true)
          {
        	  session.setAttribute("message","Record Entered Successfully<br>Normal");
              response.sendRedirect("BloodGlucose.jsp");
          }
          else if(flag==false)
          {
        	  session.setAttribute("message","Failed to submit record");
              response.sendRedirect("BloodGlucose.jsp");
          }
	}

}
