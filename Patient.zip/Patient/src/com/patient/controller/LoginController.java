package com.patient.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.BloodGlucoseDAO;
import com.patient.dao.BloodGlucoseDAOImpl;
import com.patient.dao.BmiDAO;
import com.patient.dao.BmiDAOImpl;
import com.patient.dao.RecordDAO;
import com.patient.dao.RecordDAOImpl;
import com.patient.dao.UsersDAO;
import com.patient.dao.UsersDAOImpl;
import com.patient.pojos.BloodGlucose;
import com.patient.pojos.Bmi;
import com.patient.pojos.Record;
import com.patient.pojos.Users;


/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UsersDAO dao=new UsersDAOImpl();
		HttpSession session=request.getSession();
		List<Users> userlist=dao.getAllUsers();
		session .setAttribute("userlist",userlist);
		response.sendRedirect("UserList.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		UsersDAO dao=new UsersDAOImpl();
		Users user=dao.login(userid, password);
		HttpSession session=request.getSession();
		if(user==null)
		{
			session .setAttribute("message","Invalid userid or password!!");
			response.sendRedirect("Login.jsp");
		}
			
		else
		{
			
			if(user.getType()!= null && user.getType().equals("Doctor")){
				session.setAttribute("users",user);
				List<Users> usersList= dao.getAllUsers();
				session.setAttribute("userlist",usersList);
				response.sendRedirect("UserList.jsp");
			}
			else if(user.getType()!= null && user.getType().equals("Patient")){
				session.setAttribute("users",user);
				BmiDAO bmiDAO=new BmiDAOImpl();
				Bmi bmi=bmiDAO.getDataById(userid);
				session.setAttribute("bmi",bmi);
				
				BloodGlucoseDAO bloodglucoseDAO =new BloodGlucoseDAOImpl();
				BloodGlucose bloodglucose=bloodglucoseDAO.getUserById(userid);
				session.setAttribute("bloodglucose",bloodglucose);
				

                RecordDAO recordDAO =new RecordDAOImpl();
				Record record=recordDAO.getRecordByUserid(userid);
				session.setAttribute("record",record);
		        
				response.sendRedirect("PatientHome.jsp");
			}
		}
			
	}

}
