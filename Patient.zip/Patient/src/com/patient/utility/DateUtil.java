package com.patient.utility;

import java.util.Date;

public class DateUtil {
	public static java.sql.Date convertUtilToSql(java.util.Date date){
		if(date==null)
			return new java.sql.Date(new Date().getTime());
		else
		return new java.sql.Date(date.getTime());
	}

}
